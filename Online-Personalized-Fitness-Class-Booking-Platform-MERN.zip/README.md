# Online Personalized Fitness Class Booking Platform

A MERN-stack fitness class booking platform with personalized class discovery, booking, and Razorpay payment integration.

## Tech stack
- MongoDB
- Express.js
- React.js (Vite)
- Node.js
- Tailwind CSS
- Razorpay

## Run locally

### Backend
```bash
cd backend
npm install
copy .env.example .env
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Set the values in `backend/.env`. Never commit the real `.env` file.

## Deployment
- Frontend: Netlify
- Backend: Render
- Database: MongoDB Atlas
- Payment: Razorpay test mode

## Important
Replace the placeholder Razorpay keys with your own test credentials before testing payments.
