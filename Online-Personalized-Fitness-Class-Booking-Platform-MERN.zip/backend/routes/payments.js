import express from "express";
import Razorpay from "razorpay";
import crypto from "crypto";
import Booking from "../models/Booking.js";
import FitnessClass from "../models/FitnessClass.js";
import auth from "../middleware/auth.js";

const router = express.Router();

router.post("/order", auth, async (req, res) => {
  try {
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
      return res.status(500).json({ message: "Razorpay keys are not configured on the server" });
    }
    const booking = await Booking.findOne({ _id: req.body.bookingId, user: req.user.id }).populate("fitnessClass");
    if (!booking) return res.status(404).json({ message: "Booking not found" });

    const razorpay = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
    const order = await razorpay.orders.create({ amount: Math.round(booking.amount * 100), currency: "INR", receipt: booking._id.toString() });
    booking.paymentOrderId = order.id;
    await booking.save();

    res.json({ orderId: order.id, amount: order.amount, currency: order.currency, keyId: process.env.RAZORPAY_KEY_ID });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post("/verify", auth, async (req, res) => {
  try {
    const { bookingId, razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
    const booking = await Booking.findOne({ _id: bookingId, user: req.user.id });
    if (!booking) return res.status(404).json({ message: "Booking not found" });

    const expected = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");

    if (expected !== razorpay_signature) return res.status(400).json({ message: "Payment verification failed" });

    booking.paymentId = razorpay_payment_id;
    booking.status = "Confirmed";
    await booking.save();
    await FitnessClass.findByIdAndUpdate(booking.fitnessClass, { $inc: { booked: 1 } });

    res.json({ message: "Payment verified and booking confirmed" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
