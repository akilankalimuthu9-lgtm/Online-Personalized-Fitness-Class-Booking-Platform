import express from "express";
import Booking from "../models/Booking.js";
import FitnessClass from "../models/FitnessClass.js";
import auth from "../middleware/auth.js";

const router = express.Router();

router.get("/mine", auth, async (req, res) => {
  try {
    res.json(await Booking.find({ user: req.user.id }).populate("fitnessClass").sort({ createdAt: -1 }));
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post("/", auth, async (req, res) => {
  try {
    const { fitnessClassId } = req.body;
    const fitnessClass = await FitnessClass.findById(fitnessClassId);
    if (!fitnessClass) return res.status(404).json({ message: "Class not found" });
    if (fitnessClass.booked >= fitnessClass.capacity) return res.status(400).json({ message: "Class is fully booked" });

    const existing = await Booking.findOne({ user: req.user.id, fitnessClass: fitnessClassId, status: { $in: ["Pending", "Confirmed"] } });
    if (existing) return res.status(409).json({ message: "You already have a booking for this class" });

    const booking = await Booking.create({ user: req.user.id, fitnessClass: fitnessClassId, amount: fitnessClass.price });
    res.status(201).json(booking);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
