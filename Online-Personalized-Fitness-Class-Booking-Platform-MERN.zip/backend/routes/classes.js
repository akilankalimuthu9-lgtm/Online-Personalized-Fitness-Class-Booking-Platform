import express from "express";
import FitnessClass from "../models/FitnessClass.js";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const filter = {};
    if (req.query.goal && req.query.goal !== "All") filter.goal = req.query.goal;
    if (req.query.level && req.query.level !== "All") filter.level = req.query.level;
    res.json(await FitnessClass.find(filter).sort({ date: 1, time: 1 }));
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post("/seed", async (req, res) => {
  try {
    if (await FitnessClass.countDocuments()) return res.json({ message: "Classes already exist" });
    const classes = await FitnessClass.insertMany([
      { title: "Strength & Conditioning", trainer: "Arun Kumar", description: "Build strength and improve overall conditioning.", goal: "Strength", level: "Intermediate", date: "2026-10-15", time: "07:00", duration: 60, price: 499, capacity: 15 },
      { title: "Yoga for Flexibility", trainer: "Priya Sharma", description: "Improve flexibility, mobility and mindful movement.", goal: "Flexibility", level: "Beginner", date: "2026-10-16", time: "06:30", duration: 60, price: 399, capacity: 20 },
      { title: "Weight Loss HIIT", trainer: "Rahul Dev", description: "High-intensity interval training designed for calorie burn.", goal: "Weight Loss", level: "Intermediate", date: "2026-10-17", time: "18:00", duration: 45, price: 449, capacity: 18 },
      { title: "Personal Fitness Basics", trainer: "Meena Ravi", description: "A beginner-friendly class for building a healthy routine.", goal: "General Fitness", level: "Beginner", date: "2026-10-18", time: "08:00", duration: 60, price: 349, capacity: 20 }
    ]);
    res.status(201).json(classes);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
