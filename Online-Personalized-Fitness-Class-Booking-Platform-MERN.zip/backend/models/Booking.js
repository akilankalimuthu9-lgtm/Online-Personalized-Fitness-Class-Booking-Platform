import mongoose from "mongoose";

const bookingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  fitnessClass: { type: mongoose.Schema.Types.ObjectId, ref: "FitnessClass", required: true },
  paymentOrderId: String,
  paymentId: String,
  amount: Number,
  status: { type: String, enum: ["Pending", "Confirmed", "Cancelled"], default: "Pending" }
}, { timestamps: true });

export default mongoose.model("Booking", bookingSchema);
