import mongoose from "mongoose";

const fitnessClassSchema = new mongoose.Schema({
  title: { type: String, required: true },
  trainer: { type: String, required: true },
  description: { type: String, required: true },
  goal: { type: String, required: true },
  level: { type: String, enum: ["Beginner", "Intermediate", "Advanced"], default: "Beginner" },
  date: { type: String, required: true },
  time: { type: String, required: true },
  duration: { type: Number, default: 60 },
  price: { type: Number, required: true },
  capacity: { type: Number, default: 20 },
  booked: { type: Number, default: 0 }
}, { timestamps: true });

export default mongoose.model("FitnessClass", fitnessClassSchema);
