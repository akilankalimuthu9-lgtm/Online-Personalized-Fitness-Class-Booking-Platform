import { useEffect, useState } from "react";
import { Link, Route, Routes, useNavigate } from "react-router-dom";
import api from "./api";

function Layout({ children }) {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user") || "null");
  const logout = () => { localStorage.clear(); navigate("/"); };
  return <div className="min-h-screen bg-slate-50 text-slate-900">
    <nav className="bg-slate-900 text-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link to="/" className="text-xl font-bold">FitBook</Link>
        <div className="flex items-center gap-4 text-sm">
          <Link to="/">Classes</Link>
          {user ? <><Link to="/bookings">My Bookings</Link><span>Hi, {user.name}</span><button onClick={logout} className="rounded bg-white/10 px-3 py-1">Logout</button></> :
            <Link to="/login" className="rounded bg-emerald-500 px-3 py-1 font-semibold">Login</Link>}
        </div>
      </div>
    </nav>
    <main>{children}</main>
  </div>;
}

function Home() {
  const [classes, setClasses] = useState([]);
  const [goal, setGoal] = useState("All");
  const [level, setLevel] = useState("All");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/classes?goal=${encodeURIComponent(goal)}&level=${encodeURIComponent(level)}`);
      setClasses(data);
    } catch (e) { setMessage(e.response?.data?.message || "Could not load classes"); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [goal, level]);

  const seed = async () => {
    try { await api.post("/classes/seed"); setMessage("Sample classes added."); load(); }
    catch (e) { setMessage(e.response?.data?.message || "Could not add classes"); }
  };

  return <div>
    <section className="bg-gradient-to-br from-slate-900 to-emerald-800 px-5 py-16 text-white">
      <div className="mx-auto max-w-6xl">
        <p className="mb-2 font-semibold text-emerald-300">PERSONALIZED FITNESS</p>
        <h1 className="max-w-3xl text-4xl font-black md:text-6xl">Find the right class for your fitness goal.</h1>
        <p className="mt-5 max-w-2xl text-slate-200">Discover trainers, choose a time slot and book your next workout securely online.</p>
      </div>
    </section>
    <div className="mx-auto max-w-6xl px-5 py-8">
      <div className="mb-6 flex flex-wrap gap-3 rounded-2xl bg-white p-4 shadow">
        <select value={goal} onChange={e=>setGoal(e.target.value)} className="rounded-lg border p-2">
          <option>All</option><option>Weight Loss</option><option>Strength</option><option>Flexibility</option><option>General Fitness</option>
        </select>
        <select value={level} onChange={e=>setLevel(e.target.value)} className="rounded-lg border p-2">
          <option>All</option><option>Beginner</option><option>Intermediate</option><option>Advanced</option>
        </select>
        <button onClick={seed} className="ml-auto rounded-lg bg-slate-900 px-4 py-2 text-white">Add demo classes</button>
      </div>
      {message && <p className="mb-4 rounded-lg bg-emerald-50 p-3 text-emerald-700">{message}</p>}
      {loading ? <p>Loading...</p> : <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {classes.map(c => <div key={c._id} className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
          <div className="mb-3 flex justify-between"><span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">{c.goal}</span><span className="text-sm">{c.level}</span></div>
          <h2 className="text-xl font-bold">{c.title}</h2>
          <p className="mt-2 text-sm text-slate-600">{c.description}</p>
          <div className="mt-4 space-y-1 text-sm text-slate-600"><p>Trainer: {c.trainer}</p><p>{c.date} at {c.time} · {c.duration} min</p><p>{Math.max(c.capacity-c.booked,0)} seats left</p></div>
          <div className="mt-5 flex items-center justify-between"><strong className="text-lg">₹{c.price}</strong><Link to={`/book/${c._id}`} className="rounded-lg bg-emerald-600 px-4 py-2 font-semibold text-white">Book</Link></div>
        </div>)}
      </div>}
    </div>
  </div>;
}

function Auth({ register=false }) {
  const [form, setForm] = useState({name:"",email:"",password:"",fitnessGoal:"General Fitness"});
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  const submit = async e => {
    e.preventDefault();
    try {
      const { data } = await api.post(register ? "/auth/register" : "/auth/login", form);
      localStorage.setItem("token", data.token); localStorage.setItem("user", JSON.stringify(data.user)); navigate("/");
    } catch (err) { setMessage(err.response?.data?.message || "Something went wrong"); }
  };
  return <div className="mx-auto max-w-md px-5 py-12"><form onSubmit={submit} className="rounded-2xl bg-white p-7 shadow">
    <h1 className="text-2xl font-bold">{register ? "Create account" : "Login"}</h1>
    {message && <p className="mt-3 rounded bg-red-50 p-2 text-sm text-red-700">{message}</p>}
    {register && <input required placeholder="Name" className="mt-5 w-full rounded-lg border p-3" onChange={e=>setForm({...form,name:e.target.value})}/>}
    <input required type="email" placeholder="Email" className="mt-4 w-full rounded-lg border p-3" onChange={e=>setForm({...form,email:e.target.value})}/>
    <input required minLength="6" type="password" placeholder="Password (min 6)" className="mt-4 w-full rounded-lg border p-3" onChange={e=>setForm({...form,password:e.target.value})}/>
    {register && <select className="mt-4 w-full rounded-lg border p-3" onChange={e=>setForm({...form,fitnessGoal:e.target.value})}><option>General Fitness</option><option>Weight Loss</option><option>Strength</option><option>Flexibility</option></select>}
    <button className="mt-5 w-full rounded-lg bg-emerald-600 p-3 font-semibold text-white">{register ? "Register" : "Login"}</button>
    <p className="mt-4 text-sm text-slate-600">{register ? "Already registered? " : "New user? "}<Link className="font-semibold text-emerald-700" to={register ? "/login" : "/register"}>{register ? "Login" : "Create account"}</Link></p>
  </form></div>;
}

function Book({ id }) {
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  const book = async () => {
    if (!localStorage.getItem("token")) return navigate("/login");
    try {
      const { data } = await api.post("/bookings", { fitnessClassId: id });
      setMessage("Booking created. You can now pay.");
      await startPayment(data._id);
    } catch (e) { setMessage(e.response?.data?.message || "Booking failed"); }
  };
  const startPayment = async (bookingId) => {
    try {
      const { data } = await api.post("/payments/order", { bookingId });
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => {
        const rzp = new window.Razorpay({
          key: data.keyId, amount: data.amount, currency: data.currency, name: "FitBook",
          description: "Fitness class booking", order_id: data.orderId,
          handler: async response => {
            await api.post("/payments/verify", { bookingId, ...response });
            setMessage("Payment successful! Your class is confirmed.");
            setTimeout(() => navigate("/bookings"), 1000);
          }
        });
        rzp.open();
      };
      script.onerror = () => setMessage("Could not load Razorpay checkout.");
      document.body.appendChild(script);
    } catch (e) { setMessage(e.response?.data?.message || "Payment setup failed"); }
  };
  return <div className="mx-auto max-w-xl px-5 py-12"><div className="rounded-2xl bg-white p-7 shadow">
    <h1 className="text-2xl font-bold">Confirm your booking</h1><p className="mt-3 text-slate-600">Click below to create the booking and open the Razorpay test checkout.</p>
    {message && <p className="mt-4 rounded-lg bg-emerald-50 p-3 text-emerald-700">{message}</p>}
    <button onClick={book} className="mt-6 w-full rounded-lg bg-emerald-600 p-3 font-semibold text-white">Book & Pay</button>
  </div></div>;
}

function Bookings() {
  const [items,setItems]=useState([]);
  useEffect(()=>{api.get("/bookings/mine").then(r=>setItems(r.data)).catch(()=>{});},[]);
  return <div className="mx-auto max-w-4xl px-5 py-10"><h1 className="text-3xl font-bold">My Bookings</h1><div className="mt-6 space-y-4">{items.map(b=><div key={b._id} className="rounded-xl bg-white p-5 shadow"><div className="flex justify-between"><h2 className="font-bold">{b.fitnessClass?.title}</h2><span className="font-semibold text-emerald-700">{b.status}</span></div><p className="mt-2 text-sm text-slate-600">{b.fitnessClass?.date} · {b.fitnessClass?.time} · ₹{b.amount}</p></div>)}{!items.length&&<p className="text-slate-600">No bookings yet.</p>}</div></div>;
}

export default function App() {
  return <Layout><Routes>
    <Route path="/" element={<Home/>}/>
    <Route path="/login" element={<Auth/>}/>
    <Route path="/register" element={<Auth register/>}/>
    <Route path="/book/:id" element={<BookRoute/>}/>
    <Route path="/bookings" element={<Bookings/>}/>
  </Routes></Layout>;
}

function BookRoute() {
  const id = location.pathname.split("/").pop();
  return <Book id={id}/>;
}
